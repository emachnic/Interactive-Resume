<?php $current = 8; $title = "organizations"; include 'header.php'; ?>
          <section style="height: 550px;">
            <h1>Membership in Professional Organizations</h1> 
            <ul> 
              <li>
                <a href="http://aitp.fsu.edu">Association of Information Technology Professionals</a> 
                <ul>					      
                  <li>
                    Spring 2009 to Present
                  </li> 
                </ul> 
              </li> 
              <li>
                <a href="http://tlhdotnet.org">Capital City Dot Net Users' Group</a> 
                <ul>
                  <li>
                    Spring 2009 to Present
                  </li> 
                </ul> 
              </li> 
              <li>
                Linux Users' Group at FSU
                <ul>
                  <li>
                    2007 to 2009
                  </li> 
                </ul> 
              </li> 
              <li>
                <a href="http://www.chiphifsu.com">Chi Phi Fraternity - Nu Delta Chapter</a> 
                <ul>
                  <li>
                    2003 to Present
                  </li> 
                  <li>
                    Fall 2004 - House Manager
                  </li> 
                  <li>
                    Spring 2004 to Fall 2004 - Homecoming Chair
                  </li> 
                </ul> 
              </li> 
            </ul>
          </section>
<?php include 'footer.php'; ?>
