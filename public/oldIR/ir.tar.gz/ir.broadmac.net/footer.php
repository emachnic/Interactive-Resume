        </article>
      </div>
      <footer>
        <p>
          &copy; 2009 <a href="mailto:emachnic@broadmac.net"><em>Evan Machnic</em></a>
          &bull;&nbsp;valid <a href="http://validator.w3.org/check?uri=http%3A%2F%2Fbroadmac.net%2F">HTML5</a>
          and <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a>
          &bull;&nbsp;<a href="http://wave.webaim.org/refer">WAVE</a> validated
        </p>
      </footer>
    </div>
    <script>
      CFInstall.check({
        mode: "popup"
      });
    </script>
  </body>
</html>